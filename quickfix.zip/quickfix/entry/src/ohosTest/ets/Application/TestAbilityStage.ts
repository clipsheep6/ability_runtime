import AbilityStage from "@ohos.application.AbilityStage"

export default class TestAbilityStage extends AbilityStage {
    onCreate() {
        console.log("[Demo] TestAbilityStage onCreate")
    }
}