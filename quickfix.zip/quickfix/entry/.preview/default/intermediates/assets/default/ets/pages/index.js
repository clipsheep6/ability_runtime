var _ab711b56a2264de45037cd7fd05d8a30;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../../../DevEcoStudioProjects/quickfix/entry/src/main/ets/pages/index.ets?entry":
/*!******************************************************************************************************!*\
  !*** ../../../../../../../../DevEcoStudioProjects/quickfix/entry/src/main/ets/pages/index.ets?entry ***!
  \******************************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var _ohos_application_quickFixManager_1  = globalThis.requireNapi('application.quickFixManager') || (isSystemplugin('application.quickFixManager', 'ohos') ? globalThis.ohosplugin.application.quickFixManager : isSystemplugin('application.quickFixManager', 'system') ? globalThis.systemplugin.application.quickFixManager : undefined);
var _ohos_commonEvent_1  = globalThis.requireNapi('commonEvent') || (isSystemplugin('commonEvent', 'ohos') ? globalThis.ohosplugin.commonEvent : isSystemplugin('commonEvent', 'system') ? globalThis.systemplugin.commonEvent : undefined);
let LOG_TAG = '[zyfTest]';
let APPLY_QUICK_FIX_COMMON_EVENT = 'usual.event.QUICK_FIX_APPLY_RESULT';
async function subscribeCommonEvent(result) {
    _ohos_commonEvent_1.createSubscriber({
        events: [APPLY_QUICK_FIX_COMMON_EVENT],
    }, (error, subscriber) => {
        if (error.code) {
            console.error(LOG_TAG + `create subscriber result ${JSON.stringify(error)}`);
        }
        else {
            console.log(LOG_TAG + `create subscriber succeed`);
            result = 'create subscriber succeed';
            _ohos_commonEvent_1.subscribe(subscriber, (error, data) => {
                if (error.code) {
                    console.error(LOG_TAG + `subscribe result ${JSON.stringify(error)}`);
                }
                else {
                    console.log(LOG_TAG + `callback triggered, event data: ${JSON.stringify(data)}`);
                    result = JSON.stringify(data);
                }
            });
        }
    });
}
async function applyQuickFix() {
    try {
        console.log(LOG_TAG + `Begin to apply quickfix`);
        let quickfixFiles = new Array();
        quickfixFiles[0] = '/data/storage/el2/base/haps/entry_hqf.hqf';
        console.log(LOG_TAG + `apply quick fix ${JSON.stringify(quickfixFiles)}`);
        await _ohos_application_quickFixManager_1.applyQuickFix(quickfixFiles);
        console.log(LOG_TAG + `apply quickfix succeed`);
    }
    catch (error) {
        console.log(LOG_TAG + `apply quick fix result ${JSON.stringify(error)}`);
    }
}
async function getQuickFixInfo(result) {
    try {
        console.log(LOG_TAG + `begin to get quickfix info`);
        let bundleName = 'com.example.quickfixnosoabc';
        let info = await _ohos_application_quickFixManager_1.getApplicationQuickFixInfo(bundleName);
        console.log(LOG_TAG + `get quickfix info succeed`);
        console.log(`quickfix info ${JSON.stringify(info)}`);
        result = JSON.stringify(info);
    }
    catch (error) {
        console.log(LOG_TAG + `get quick fix result ${JSON.stringify(error)}`);
    }
}
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params) {
        super(compilerAssignedUniqueChildId, parent);
        this.__message = new ObservedPropertySimple('Quick Fix Demo', this, "message");
        this.__resultInfo = new ObservedPropertySimple('', this, "resultInfo");
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.resultInfo !== undefined) {
            this.resultInfo = params.resultInfo;
        }
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__resultInfo.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    get resultInfo() {
        return this.__resultInfo.get();
    }
    set resultInfo(newValue) {
        this.__resultInfo.set(newValue);
    }
    render() {
        Row.create();
        Row.debugLine("pages/index.ets(61:5)");
        Row.height('100%');
        Column.create();
        Column.debugLine("pages/index.ets(62:7)");
        Column.width('100%');
        Text.create(this.message);
        Text.debugLine("pages/index.ets(63:9)");
        Text.fontSize(40);
        Text.fontWeight(FontWeight.Bold);
        Text.pop();
        Button.createWithChild();
        Button.debugLine("pages/index.ets(67:9)");
        Button.type(ButtonType.Capsule);
        Button.margin({
            top: 20
        });
        Button.backgroundColor('#0D9FFB');
        Button.width('80%');
        Button.height('5%');
        Button.onClick(() => {
            subscribeCommonEvent((result) => {
                this.resultInfo = result;
            });
        });
        Text.create('Subscribe Common event');
        Text.debugLine("pages/index.ets(68:11)");
        Text.fontSize(20);
        Text.fontWeight(FontWeight.Bold);
        Text.pop();
        Button.pop();
        Button.createWithChild();
        Button.debugLine("pages/index.ets(85:9)");
        Button.type(ButtonType.Capsule);
        Button.margin({
            top: 20
        });
        Button.backgroundColor('#0D9FFB');
        Button.width('80%');
        Button.height('5%');
        Button.onClick(() => {
            applyQuickFix();
        });
        Text.create('Apply Quick Fix');
        Text.debugLine("pages/index.ets(86:11)");
        Text.fontSize(20);
        Text.fontWeight(FontWeight.Bold);
        Text.pop();
        Button.pop();
        Button.createWithChild();
        Button.debugLine("pages/index.ets(101:9)");
        Button.type(ButtonType.Capsule);
        Button.margin({
            top: 20
        });
        Button.backgroundColor('#0D9FFB');
        Button.width('80%');
        Button.height('5%');
        Button.onClick(() => {
            getQuickFixInfo((result) => {
                this.resultInfo = result;
            });
        });
        Text.create('Get Quick Fix Info');
        Text.debugLine("pages/index.ets(102:11)");
        Text.fontSize(20);
        Text.fontWeight(FontWeight.Bold);
        Text.pop();
        Button.pop();
        Text.create(this.resultInfo);
        Text.debugLine("pages/index.ets(119:9)");
        Text.fontSize(16);
        Text.width('80%');
        Text.margin({ top: 20 });
        Text.constraintSize({ minHeight: 40 });
        Text.padding(10);
        Text.border({ width: 1, color: Color.Gray, radius: 20 });
        Text.pop();
        Column.pop();
        Row.pop();
    }
}
loadDocument(new Index("1", undefined, {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["../../../../../../../../DevEcoStudioProjects/quickfix/entry/src/main/ets/pages/index.ets?entry"](0, __webpack_exports__);
/******/ 	_ab711b56a2264de45037cd7fd05d8a30 = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=index.js.map